clear all

tspan = [0 100];
% initial values
U0 = 1;
W0 = 0;
Q0 =0;
Theta0 = 0;

x0 = [U0
    W0
    Q0
    Theta0];

[t,x] = ode45(@Longitudinal_Aircraft,tspan,x0);
subplot(4,1,1);
plot(t,x(:,1));
xlabel('time[s]');
ylabel('U[m/s]');

subplot(4,1,2);
plot(t,x(:,2));
xlabel('time[s]');
ylabel('W[m/s]');

subplot(4,1,3);
plot(t,x(:,3));
xlabel('time[s]');
ylabel('Q[rad/s]');

subplot(4,1,4);
plot(t,x(:,4)/pi*180);
xlabel('time[s]');
ylabel('pitch angle[deg]');




