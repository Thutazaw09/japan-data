function dxdt = Longitudinal_Aircraft(t,x)

U = x(1);
W = x(2);
Q =x(3);
Theta = x(4);

g = 9.8;            % gravitational acceleration [m/s2]
m = 0.01;           % mass [kg] (temporarily value)
Iyy =0.001;         % moment of inertia [kgm2] (temporarily value)
lw = -0.01;          % Distance between the main wing and the center of gravity [m]  (temporarily value)
lt = 0.3;           % Distance between the horizontal stabilizer and the center of gravity [m]  (temporarily value)
bw = 0.4;           % span of main wing [m]   (temporarily value)
cw = 0.05;          % chord length of main wing [m]   (temporarily value)
bt = 0.2;           % span of horizontal stabilizer [m]   (temporarily value)
ct = 0.05;          % chord length of horizontal stabilizer [m]   (temporarily value)
eta = 1 / 180 * pi;% angle of horizontal stabilizer [rad]   (temporarily value)

rho = 1.29;         % air density kg/m3
Clalpha = 2 * pi;   % 2D lift curve slope

Sw = bw * cw;
St = bt * ct;

Aw = bw^2/Sw;
At = bt^2/St;

aw = Clalpha * Aw / (2 + sqrt(4 + Aw^2));
at = Clalpha * At / (2 + sqrt(4 + At^2));

CLw0 = 0;
CLt0 = 0;

ew = 1;
et = 1;

CDw0 = 0.002;
CDt0 = 0.002;


alpha = atan(W/U);
alpha_w = alpha;
alpha_t = atan((W+lt*Q)/U);

CLw = CLw0 + aw * alpha_w;
CLt = CLt0 + at * (alpha_t + eta);
CDw = CDw0 + CLw^2 / (pi * ew * Aw);
CDt = CDt0 + CLt^2 / (pi * et * At);


Lw = 1/2 * rho *(U^2 + W^2) * Sw * CLw;
Lt = 1/2 * rho *(U^2 + W^2) * St * CLt;
Dw = 1/2 * rho *(U^2 + W^2) * Sw * CDw;
Dt = 1/2 * rho *(U^2 + W^2) * St * CDt;


Xa =  Lw*sin(alpha) + Lt * sin(alpha_t) - Dw*cos(alpha) - Dt * cos(alpha_t);
Za = -Lw*cos(alpha) - Lt * cos(alpha_t) - Dw*sin(alpha) - Dt * sin(alpha_t);
M = lw * Lw - lt * Lt;


Udot = -Q*W - g * sin(Theta) + Xa/m;
Wdot =  Q*U + g * cos(Theta) + Za /m;
Qdot = M / Iyy;
Thetadot = Q;


dxdt = [Udot
        Wdot
        Qdot
        Thetadot];


